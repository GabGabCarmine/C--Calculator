using System.Collections;

namespace Calculadora_CSharp
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public decimal Resultado { get; set; } //propriedade para armazenar resultado
        public decimal Valor { get; set; } //propriedade para armazenar valor

        private Operacao OperacaoSelecionada { get; set; } //propriedade que vai puxar a opera��o informada

        private enum Operacao //vai servir para puxar a opera��o a ser executada
        {
            Adicao,
            Subtracao,
            Divisao,
            Multiplicacao
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void B0_Click(object sender, EventArgs e) //botao 0, B de bot�o e 0 o numero, serve para digitar em tela
        {
            TXTResultado.Text += "0"; //digita o numero 0 na tela
        }

        private void B1_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "1";
        }

        private void B2_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "2";
        }

        private void B3_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "3";
        }

        private void B4_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "4";
        }

        private void B5_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "5";
        }

        private void B6_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "6";
        }

        private void B7_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "7";
        }

        private void B8_Click(object sender, EventArgs e)
        {
            TXTResultado.Text += "8";
        }

        private void B9_Click(object sender, EventArgs e) //aqui termina os botoes numerais
        {
            TXTResultado.Text += "9";
        }

        private void BSoma_Click(object sender, EventArgs e) //Seleciona a opera��o somar
        {
            OperacaoSelecionada = Operacao.Adicao; //seleciona opera��o adi��o
            Valor = Convert.ToDecimal(TXTResultado.Text); //armazena o valor atual na propriedade, fazendo conversao de string para decimal
            TXTResultado.Text = ""; //apaga o valor que aparece em tela para acrescentar o que vai ser somado
            lbl.Text = "+"; //mostra a opera��o em tela
        }

        private void BDivide_Click(object sender, EventArgs e)
        {
            OperacaoSelecionada = Operacao.Divisao;
            Valor = Convert.ToDecimal(TXTResultado.Text);
            TXTResultado.Text = "";
            lbl.Text = "/";
        }

        private void BMultiplica_Click(object sender, EventArgs e)
        {
            OperacaoSelecionada = Operacao.Multiplicacao;
            Valor = Convert.ToDecimal(TXTResultado.Text);
            TXTResultado.Text = "";
            lbl.Text = "*";
        }

        private void BSubtrai_Click(object sender, EventArgs e) //aqui termina a parte de opera��es
        {
            OperacaoSelecionada = Operacao.Subtracao;
            Valor = Convert.ToDecimal(TXTResultado.Text);
            TXTResultado.Text = "";
            lbl.Text = "-";
        }

        private void BIgual_Click(object sender, EventArgs e) //aqui seleciona a fun��o do =
        {
            switch (OperacaoSelecionada)
            {
                case Operacao.Adicao: //caso tenha escolhido + ele executa uma soma
                    Resultado = Valor + Convert.ToDecimal(TXTResultado.Text); //Resultado � o que vai ser mostrado ao ser clicado em igual
                    break;
                case Operacao.Divisao:
                    Resultado = Valor / Convert.ToDecimal(TXTResultado.Text);
                    break;
                case Operacao.Multiplicacao:
                    Resultado = Valor * Convert.ToDecimal(TXTResultado.Text);
                    break;
                case Operacao.Subtracao:
                    Resultado = Valor - Convert.ToDecimal(TXTResultado.Text);
                    break;

            }
            TXTResultado.Text = Convert.ToString(Resultado); //aqui mostra o resultado em tela
            lbl.Text = ""; //apaga o simbolo de opera��o
        }

        private void BVirgula_Click(object sender, EventArgs e) //acrescenta virgula
        {
            if (!TXTResultado.Text.Contains(",")) //verifica se tem virgula, caso tenha ele anula a fun��o do bot�o
            {
                TXTResultado.Text += ",";
            }
        }

        private void BReseta_Click(object sender, EventArgs e) //reinicia
        {
            TXTResultado.Text = "";
            lbl.Text = "";
        }
    }
}

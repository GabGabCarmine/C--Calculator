﻿namespace Calculadora_CSharp
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            TXTResultado = new TextBox();
            B0 = new Button();
            B1 = new Button();
            B2 = new Button();
            B3 = new Button();
            B4 = new Button();
            B5 = new Button();
            B6 = new Button();
            B7 = new Button();
            B8 = new Button();
            B9 = new Button();
            BIgual = new Button();
            BReseta = new Button();
            BMultiplica = new Button();
            BDivide = new Button();
            BSoma = new Button();
            BSubtrai = new Button();
            BVirgula = new Button();
            lbl = new Label();
            SuspendLayout();
            // 
            // TXTResultado
            // 
            TXTResultado.Location = new Point(12, 12);
            TXTResultado.Name = "TXTResultado";
            TXTResultado.ReadOnly = true;
            TXTResultado.Size = new Size(246, 24);
            TXTResultado.TabIndex = 0;
            TXTResultado.TextAlign = HorizontalAlignment.Right;
            TXTResultado.TextChanged += textBox1_TextChanged;
            // 
            // B0
            // 
            B0.Location = new Point(12, 224);
            B0.Name = "B0";
            B0.Size = new Size(57, 55);
            B0.TabIndex = 1;
            B0.Text = "0";
            B0.UseVisualStyleBackColor = true;
            B0.Click += B0_Click;
            // 
            // B1
            // 
            B1.Location = new Point(12, 163);
            B1.Name = "B1";
            B1.Size = new Size(57, 55);
            B1.TabIndex = 2;
            B1.Text = "1";
            B1.UseVisualStyleBackColor = true;
            B1.Click += B1_Click;
            // 
            // B2
            // 
            B2.Location = new Point(75, 163);
            B2.Name = "B2";
            B2.Size = new Size(57, 55);
            B2.TabIndex = 3;
            B2.Text = "2";
            B2.UseVisualStyleBackColor = true;
            B2.Click += B2_Click;
            // 
            // B3
            // 
            B3.Location = new Point(138, 163);
            B3.Name = "B3";
            B3.Size = new Size(57, 55);
            B3.TabIndex = 4;
            B3.Text = "3";
            B3.UseVisualStyleBackColor = true;
            B3.Click += B3_Click;
            // 
            // B4
            // 
            B4.Location = new Point(12, 102);
            B4.Name = "B4";
            B4.Size = new Size(57, 55);
            B4.TabIndex = 5;
            B4.Text = "4";
            B4.UseVisualStyleBackColor = true;
            B4.Click += B4_Click;
            // 
            // B5
            // 
            B5.Location = new Point(75, 102);
            B5.Name = "B5";
            B5.Size = new Size(57, 55);
            B5.TabIndex = 6;
            B5.Text = "5";
            B5.UseVisualStyleBackColor = true;
            B5.Click += B5_Click;
            // 
            // B6
            // 
            B6.Location = new Point(138, 102);
            B6.Name = "B6";
            B6.Size = new Size(57, 55);
            B6.TabIndex = 7;
            B6.Text = "6";
            B6.UseVisualStyleBackColor = true;
            B6.Click += B6_Click;
            // 
            // B7
            // 
            B7.Location = new Point(12, 41);
            B7.Name = "B7";
            B7.Size = new Size(57, 55);
            B7.TabIndex = 8;
            B7.Text = "7";
            B7.UseVisualStyleBackColor = true;
            B7.Click += B7_Click;
            // 
            // B8
            // 
            B8.Location = new Point(75, 41);
            B8.Name = "B8";
            B8.Size = new Size(57, 55);
            B8.TabIndex = 9;
            B8.Text = "8";
            B8.UseVisualStyleBackColor = true;
            B8.Click += B8_Click;
            // 
            // B9
            // 
            B9.Location = new Point(138, 41);
            B9.Name = "B9";
            B9.Size = new Size(57, 55);
            B9.TabIndex = 10;
            B9.Text = "9";
            B9.UseVisualStyleBackColor = true;
            B9.Click += B9_Click;
            // 
            // BIgual
            // 
            BIgual.Location = new Point(75, 224);
            BIgual.Name = "BIgual";
            BIgual.Size = new Size(57, 55);
            BIgual.TabIndex = 11;
            BIgual.Text = "=";
            BIgual.UseVisualStyleBackColor = true;
            BIgual.Click += BIgual_Click;
            // 
            // BReseta
            // 
            BReseta.Location = new Point(138, 224);
            BReseta.Name = "BReseta";
            BReseta.Size = new Size(57, 55);
            BReseta.TabIndex = 12;
            BReseta.Text = "C";
            BReseta.UseVisualStyleBackColor = true;
            BReseta.Click += BReseta_Click;
            // 
            // BMultiplica
            // 
            BMultiplica.Location = new Point(201, 41);
            BMultiplica.Name = "BMultiplica";
            BMultiplica.Size = new Size(57, 55);
            BMultiplica.TabIndex = 13;
            BMultiplica.Text = "*";
            BMultiplica.UseVisualStyleBackColor = true;
            BMultiplica.Click += BMultiplica_Click;
            // 
            // BDivide
            // 
            BDivide.Location = new Point(201, 102);
            BDivide.Name = "BDivide";
            BDivide.Size = new Size(57, 55);
            BDivide.TabIndex = 14;
            BDivide.Text = "/";
            BDivide.UseVisualStyleBackColor = true;
            BDivide.Click += BDivide_Click;
            // 
            // BSoma
            // 
            BSoma.Location = new Point(201, 163);
            BSoma.Name = "BSoma";
            BSoma.Size = new Size(57, 55);
            BSoma.TabIndex = 15;
            BSoma.Text = "+";
            BSoma.UseVisualStyleBackColor = true;
            BSoma.Click += BSoma_Click;
            // 
            // BSubtrai
            // 
            BSubtrai.Location = new Point(201, 224);
            BSubtrai.Name = "BSubtrai";
            BSubtrai.Size = new Size(57, 55);
            BSubtrai.TabIndex = 16;
            BSubtrai.Text = "-";
            BSubtrai.UseVisualStyleBackColor = true;
            BSubtrai.Click += BSubtrai_Click;
            // 
            // BVirgula
            // 
            BVirgula.Location = new Point(12, 285);
            BVirgula.Name = "BVirgula";
            BVirgula.Size = new Size(57, 55);
            BVirgula.TabIndex = 17;
            BVirgula.Text = ",";
            BVirgula.UseVisualStyleBackColor = true;
            BVirgula.Click += BVirgula_Click;
            // 
            // lbl
            // 
            lbl.AutoSize = true;
            lbl.Location = new Point(12, 15);
            lbl.Name = "lbl";
            lbl.Size = new Size(0, 15);
            lbl.TabIndex = 20;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaption;
            ClientSize = new Size(271, 346);
            Controls.Add(lbl);
            Controls.Add(BVirgula);
            Controls.Add(BSubtrai);
            Controls.Add(BSoma);
            Controls.Add(BDivide);
            Controls.Add(BMultiplica);
            Controls.Add(BReseta);
            Controls.Add(BIgual);
            Controls.Add(B9);
            Controls.Add(B8);
            Controls.Add(B7);
            Controls.Add(B6);
            Controls.Add(B5);
            Controls.Add(B4);
            Controls.Add(B3);
            Controls.Add(B2);
            Controls.Add(B1);
            Controls.Add(B0);
            Controls.Add(TXTResultado);
            Cursor = Cursors.Hand;
            Font = new Font("Segoe UI Semibold", 9F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            Icon = (Icon)resources.GetObject("$this.Icon");
            Name = "Form1";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Calculadora";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox TXTResultado;
        private Button B0;
        private Button B1;
        private Button B2;
        private Button B3;
        private Button B4;
        private Button B5;
        private Button B6;
        private Button B7;
        private Button B8;
        private Button B9;
        private Button BIgual;
        private Button BReseta;
        private Button BMultiplica;
        private Button BDivide;
        private Button BSoma;
        private Button BSubtrai;
        private Button BVirgula;
        private Label lbl;
    }
}
